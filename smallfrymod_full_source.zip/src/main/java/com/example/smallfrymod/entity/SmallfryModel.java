// Auto-generated GeckoLib model for Smallfry
package com.example.smallfrymod.entity;

import software.bernie.geckolib.model.GeoModel;
import net.minecraft.resources.ResourceLocation;
import com.example.smallfrymod.SmallfryMod;
import net.minecraft.client.model.geom.ModelPart;

public class SmallfryModel extends GeoModel<SmallfryEntity> {
    @Override
    public ResourceLocation getModelResource(SmallfryEntity object) {
        return new ResourceLocation(SmallfryMod.MODID, "geo/smallfry.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(SmallfryEntity object) {
        return new ResourceLocation(SmallfryMod.MODID, "textures/entity/smallfry_texture.png");
    }

    @Override
    public ResourceLocation getAnimationResource(SmallfryEntity animatable) {
        return new ResourceLocation(SmallfryMod.MODID, "animations/smallfry.animation.json");
    }
}